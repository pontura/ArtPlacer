package com.yusufolokoba.natcam;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.media.ExifInterface;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Surface;

import com.google.android.gms.vision.barcode.Barcode;
import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;

/**
 * NatCam
 *
 * Created by yusuf on 4/17/16.
 */

public class NatCamExtensions {

    static boolean verboseMode;

    public static void SetOptions (boolean verbose) {
        verboseMode = verbose;
    }

    public static void Assert (String log) {
        if (verboseMode) Log.d("Unity", "NatCam Logging: " + log);
    }

    public static void Log (String log) {
        Log.d("Unity", log);
    }

    public static Camera.Size ClosestResolution (Camera.Parameters params, int width, int height) {
        List<Camera.Size> resolutions = params.getSupportedPreviewSizes();
        Camera.Size bestResolution = resolutions.get(0);
        for (int i = 0, len = resolutions.size(); i < len; i++) {
            Camera.Size resolution = resolutions.get(i);
            int curDelta = Math.abs(resolution.width - width) + Math.abs(resolution.height - height);
            int bestDelta = Math.abs(bestResolution.width - width) + Math.abs(bestResolution.height - height);
            bestResolution = curDelta < bestDelta ? resolution : bestResolution;
        }
        return bestResolution;
    }

    public static int[] ClosestFramerate (Camera.Parameters params, float frameRate) {
        int framerate = (int)(frameRate * 1000);
        List<int[]> rates = params.getSupportedPreviewFpsRange();
        int[] bestFramerate = rates.get(0);
        for (int i = 0, len = rates.size(); i < len; i++) {
            int[] rate = rates.get(i);
            int curDelta = Math.abs(rate[1] - framerate);
            int bestDelta = Math.abs(bestFramerate[1] - framerate);
            bestFramerate = curDelta < bestDelta ? rate : bestFramerate;
        }
        return bestFramerate;
    }

    public static Camera.Size HighestPhotoResolution (Camera.Parameters params) {
        List<Camera.Size> sizes = params.getSupportedPictureSizes();
        int count = sizes.size();
        Camera.Size first = count > 1 ? sizes.get(1) : sizes.get(0);
        Camera.Size last = count > 1 ? sizes.get(count - 2) : sizes.get(count - 1); //Minimal speedup
        Camera.Size highestResolution = first.width > last.width ? first : last;
        return highestResolution;
    }

    public static String FocusMode (int mode) {
        String ret = Camera.Parameters.FOCUS_MODE_AUTO;
        switch (mode) {
            case 0:
                ret = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE;
                break;
            case 1:
                ret = Camera.Parameters.FOCUS_MODE_FIXED;
                break;
        }
        return ret;
    }

    public static String FlashMode (int mode) {
        String ret = Camera.Parameters.FLASH_MODE_AUTO;
        switch (mode) {
            case 0:
                ret = Camera.Parameters.FLASH_MODE_AUTO;
                break;
            case 1:
                ret = Camera.Parameters.FLASH_MODE_ON;
                break;
            case 2:
                ret = Camera.Parameters.FLASH_MODE_OFF;
                break;
        }
        return ret;
    }

    public static Camera GetCamera (int index, SurfaceTexture surfaceTexture) {
        Camera cam = Camera.open(index);
        try {
            cam.setPreviewTexture(surfaceTexture); //Necessary for some devices especially Nexus.
        } catch (IOException ex) {
            Log("NatCam Error: Failed to set an important attribute for camera "+index+". Might encounter errors");
        }
        return cam;
    }

    public static int MRCodeFormat (int format) {
        if (format == Barcode.QR_CODE) return 1;
        if (format == Barcode.EAN_13) return 2;
        if (format == Barcode.EAN_8) return 4;
        if (format == Barcode.DATA_MATRIX) return 8;
        if (format == Barcode.PDF417) return 16;
        if (format == Barcode.CODE_128) return 32;
        if (format == Barcode.CODE_93) return 64;
        if (format == Barcode.CODE_39) return 128;
        if (format == Barcode.ISBN) return 2; //ISBN as EAN13
        return 8;
    }

    public static Rect FocusArea (float x, float y) {
        int FOCUS_AREA_SIZE= 300; //Const
        int left = Clamp(Float.valueOf(x * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);
        int top = Clamp(Float.valueOf(y * 2000 - 1000).intValue(), FOCUS_AREA_SIZE);
        return new Rect(left, top, left + FOCUS_AREA_SIZE, top + FOCUS_AREA_SIZE);
    }

    private static int Clamp (int coord, int size) {
        int result = (Math.abs(coord) + size/2) > 1000 ? coord > 0 ? 1000 - size/2 : -1000 + size/2 : coord - size/2;
        return result;
    }

    public static void SavePhotoToDisk (Handler handler, int saveMode, byte[] data, float _rotation, float _flip) { //OPTIMIZE
        if (saveMode == 0) return;
        final int photoSaveMode = saveMode;
        final Context context = UnityPlayer.currentActivity;
        final byte[] photoData = data;
        final int flip = (int)(_flip * 2 - 1); //transpose from [0, 1] to [-1, 1]
        final int rotation = (int)(_rotation * 180) + (flip == -1 ? 180 : 0);
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (photoSaveMode == 1) { //Save to photos
                    String root = Environment.getExternalStorageDirectory().toString();
                    String[] appIDTokens = UnityPlayer.currentActivity.getPackageName().split(Pattern.quote("."));
                    String lowerName = appIDTokens[appIDTokens.length - 1].toLowerCase();
                    String appName = Character.toUpperCase(lowerName.charAt(0)) + lowerName.substring(1);
                    File myDir = new File(root + "/" + appName);
                    myDir.mkdirs();
                    Random generator = new Random();
                    String photoName = "photo_"+ generator.nextInt(48141) +".jpg";
                    File file = new File (myDir, photoName);
                    if (file.exists ()) file.delete ();
                    try {
                        Bitmap photo = BitmapFactory.decodeByteArray(photoData, 0, photoData.length);
                        Matrix matrix = new Matrix();
                        matrix.preRotate(rotation);
                        matrix.postScale(1, flip);
                        photo = Bitmap.createBitmap(photo, 0, 0, photo.getWidth(), photo.getHeight(), matrix, false);
                        FileOutputStream out = new FileOutputStream(file);
                        photo.compress(Bitmap.CompressFormat.JPEG, 90, out);
                        out.close();
                        photo.recycle();
                        photo = null;
                        //Add to gallery
                        MediaStore.Images.Media.insertImage(context.getContentResolver(), file.getAbsolutePath(), photoName, "");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (photoSaveMode == 2) { //Save to app album //UPDATE //ABOVE
                    String root = Environment.getExternalStorageDirectory().toString();
                    String[] appIDTokens = UnityPlayer.currentActivity.getPackageName().split(Pattern.quote("."));
                    String lowerName = appIDTokens[appIDTokens.length - 1].toLowerCase();
                    String appName = Character.toUpperCase(lowerName.charAt(0)) + lowerName.substring(1);
                    File myDir = new File(root + "/" + appName);
                    myDir.mkdirs();
                    Random generator = new Random();
                    String photoName = "photo_"+ generator.nextInt(48141) +".jpg";
                    File file = new File (myDir, photoName);
                    if (file.exists ()) file.delete ();
                    try {
                        Bitmap photo = BitmapFactory.decodeByteArray(photoData, 0, photoData.length);
                        Matrix matrix = new Matrix();
                        matrix.preRotate(rotation);
                        matrix.postScale(1, flip);
                        photo = Bitmap.createBitmap(photo, 0, 0, photo.getWidth(), photo.getHeight(), matrix, false);
                        FileOutputStream out = new FileOutputStream(file);
                        photo.compress(Bitmap.CompressFormat.JPEG, 90, out);
                        out.close();
                        photo.recycle();
                        photo = null;
                        //Add to gallery
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        values.put(MediaStore.MediaColumns.DATA, file.getAbsolutePath());
                        context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private static int GetOrientationTag () {
        int rotation = UnityPlayer.currentActivity.getWindowManager().getDefaultDisplay().getRotation();
        switch (rotation) {
            case Surface.ROTATION_0: //Portrait
                return ExifInterface.ORIENTATION_ROTATE_90;
            case Surface.ROTATION_90: //Landscape Left
                return ExifInterface.ORIENTATION_NORMAL;
            case Surface.ROTATION_180: //Portrait Upside down
                return ExifInterface.ORIENTATION_ROTATE_180;
            case Surface.ROTATION_270: //Landscape Right
                return ExifInterface.ORIENTATION_ROTATE_270;
            default:
                return ExifInterface.ORIENTATION_NORMAL;
        }
    }
}
