/**
 * NatCam
 *
 * Created by Yusuf on 4/17/16.
 */

package com.yusufolokoba.natcam;

import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.*;
import android.os.Process;
import android.support.v4.content.PermissionChecker;
import android.util.SparseArray;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.unity3d.player.UnityPlayer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

import static com.yusufolokoba.natcam.NatCamExtensions.*;

public class NatCamNativeActivity {

    //State
    int activeCamera = -1; //Force devs to call NatCam.set_ActiveCamera()
    boolean inspectedDevice;
    boolean initializedSession;
    //Devices
    Camera mCamera;
    Camera.Parameters[] IntrinsicProperties;
    Camera.Size[] Resolutions;
    int[][] Framerates;
    String[] FocusModes;
    String[] FlashModes;
    //Ops
    boolean readablePreview;
    boolean mrDetection;
    int photoSaveMode;
    //Preview
    int _width, _height;
    byte[] PreviewBuffer;
    ByteBuffer yBuffer, uvBuffer;
    SurfaceTexture previewSurfaceTex;
    //Barcode detection
    boolean isScanningCodes = false;
    BarcodeDetector detector;
    Frame detectorFrame;
    //Utility
    float _rotation, _flip;

    //Threads
    static HandlerThread mCameraThread;
    static Handler mCameraHandler;
    static HandlerThread mrProcessingThread;
    static Handler mrProcessor;

    //region ---JNI---
    static {
        System.loadLibrary("NatCam");
    }
    native static final boolean InitializedRenderer ();
    native static final void InitializeOptions (boolean readablePreview, boolean verbose);
    native static final void UpdateDimensions (int width, int height);
    native static final void RequestRenderCallback (int callback);
    native static final void ReportPhoto (byte[] photoData, int dataSize);
    native static final void ReportBarcode (String token);
    native static final void ReportUpdateState (boolean state);
    //endregion


    //region ---Top Level Initialization---

    void InspectDevice (boolean readable, boolean mrDetect, boolean verbose) {
        readablePreview = readable;
        mrDetection = mrDetect;
        SetOptions(verbose);
        if (!inspectedDevice) PerformInspection();
    }

    public static boolean HasPermissions () { //Not part of the pipeline, so static
        boolean result = true; //Permissions are always granted before API Level 23
        int targetSdkVersion = 16; //NatCam's minimum
        String permission = android.Manifest.permission.CAMERA; //Also consider checking for flashlight
        try {
            targetSdkVersion = UnityPlayer.currentActivity.getPackageManager().getPackageInfo(UnityPlayer.currentActivity.getPackageName(), 0).applicationInfo.targetSdkVersion;
        }
        catch (PackageManager.NameNotFoundException e) {
            Log("NatCam Error: Unable to check for camera permission with error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (targetSdkVersion >= Build.VERSION_CODES.M) {
                result = UnityPlayer.currentActivity.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
            }
            else {
                result = PermissionChecker.checkSelfPermission(UnityPlayer.currentActivity, permission) == PermissionChecker.PERMISSION_GRANTED;
            }
        }
        return result;
    }

    void PerformInspection () {
        if (previewSurfaceTex == null) previewSurfaceTex = new SurfaceTexture(0);
        int count = Camera.getNumberOfCameras();
        IntrinsicProperties = new Camera.Parameters[count];
        Resolutions = new Camera.Size[count];
        Framerates = new int[count][];
        FocusModes = new String[count];
        FlashModes = new String[count];
        for (int i = 0; i < count; i++) {
            mCamera = GetCamera(i, previewSurfaceTex);
            IntrinsicProperties[i] = mCamera.getParameters();
            FocusModes[i] = Camera.Parameters.FOCUS_MODE_AUTO;
            Resolutions[i] = IntrinsicProperties[i].getPreviewSize();
            Framerates[i] = ClosestFramerate(IntrinsicProperties[i], 30);
            mCamera.release(); //Release
            mCamera = null;
        }
        inspectedDevice = true;
        Log("NatCam: Inspected Device: Found " + count + " cameras");
    }

    public void InitializeSession (int camera) {
        //Get the camera preview width and height
        _width = Resolutions[camera].width;
        _height = Resolutions[camera].height;
        //Initialize options in the native layer
        InitializeOptions(readablePreview, verboseMode);
        //We slightly over-allocate because Android.
        PreviewBuffer = new byte[4096 + _width * _height * 12 / 8];
        //Alloc buffers
        yBuffer = ByteBuffer.allocateDirect(_width * _height);
        uvBuffer = ByteBuffer.allocateDirect(_width * _height / 2);
        yBuffer.order(ByteOrder.nativeOrder());
        uvBuffer.order(ByteOrder.nativeOrder());
        //Camera thread
        if (mCameraThread == null) {
            mCameraThread = new HandlerThread("NatCamCameraThread", android.os.Process.THREAD_PRIORITY_FOREGROUND);
            mCameraThread.start();
            mCameraHandler = new Handler(mCameraThread.getLooper());
        }
        //Barcode processing
        if (mrProcessingThread == null) {
            mrProcessingThread = new HandlerThread("NatCamBarcodeThread", Process.THREAD_PRIORITY_BACKGROUND + Process.THREAD_PRIORITY_MORE_FAVORABLE);
            mrProcessingThread.start();
            mrProcessor = new Handler(mrProcessingThread.getLooper());
        }
        initializedSession = true;
        Log("NatCam: Initialized");
    }
    //endregion


    //region ---Learning---

    int[] GetActiveResolution (int camera) {
        if (!inspectedDevice) PerformInspection();
        int[] ret = {Resolutions[camera].width, Resolutions[camera].height};
        return ret;
    }

    boolean IsRearFacing (int camera) {
        if (!inspectedDevice) PerformInspection();
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(camera, cameraInfo);
        return cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK;
    }

    boolean IsFlashSupported (int camera) {
        if (!inspectedDevice) PerformInspection();
        Camera.Parameters params = IntrinsicProperties[camera];
        return params.getSupportedFlashModes() != null && params.getSupportedFlashModes().contains(Camera.Parameters.FLASH_MODE_ON);
    }

    boolean IsTorchSupported (int camera) {
        if (!inspectedDevice) PerformInspection();
        Camera.Parameters params = IntrinsicProperties[camera];
        return params.getSupportedFlashModes() != null && params.getSupportedFlashModes().contains(Camera.Parameters.FLASH_MODE_TORCH);
    }

    boolean IsZoomSupported (int camera) {
        if (!inspectedDevice) PerformInspection();
        Camera.Parameters params = IntrinsicProperties[camera];
        return params.isSmoothZoomSupported();
    }

    float HorizontalFOV (int camera) {
        if (!inspectedDevice) PerformInspection();
        Camera.Parameters params = IntrinsicProperties[camera];
        return params.getHorizontalViewAngle();
    }

    float VerticalFOV (int camera) {
        if (!inspectedDevice) PerformInspection();
        Camera.Parameters params = IntrinsicProperties[camera];
        return params.getVerticalViewAngle();
    }
    //endregion


    //region ---Control---

    void SetResolution (int camera, int width, int height) {
        if (!inspectedDevice) PerformInspection();
        Resolutions[camera] = ClosestResolution(IntrinsicProperties[camera], width, height);
        Assert("Changed camera resolution to " + Resolutions[camera].width + "x" + Resolutions[camera].height);
    }

    void SetFramerate (int camera, float framerate) {
        if (!inspectedDevice) PerformInspection();
        Framerates[camera] = ClosestFramerate (IntrinsicProperties[camera], framerate);
        Assert("Changed camera framerate to "+Framerates[camera][1]);
    }

    void SetFocus (int camera, float x, float y) {
        if (!inspectedDevice) PerformInspection();
        if (activeCamera != camera) {
            Log("NatCam Error: Can only set focus on active camera");
            return;
        }
        Assert("Attempting to focus camera " + camera + " at (" + Math.round(x * 100) / 100f + ", " + Math.round(y * 100) / 100f + ")");
        Camera device = mCamera;
        Camera.Parameters params = mCamera.getParameters(); //Parameters[camera];
        if (params.getMaxNumMeteringAreas() > 0 && params.getMaxNumFocusAreas() > 0) {
            device.cancelAutoFocus();
            if (params.getFocusMode() != Camera.Parameters.FOCUS_MODE_AUTO) {
                if (params.getSupportedFocusModes().contains(params.FOCUS_MODE_AUTO))
                    params.setFocusMode(params.FOCUS_MODE_AUTO);
            }
            List<Camera.Area> meteringAreas = new ArrayList<Camera.Area>();
            meteringAreas.add(new Camera.Area(FocusArea (x, y), 800));
            params.setFocusAreas(meteringAreas);
            device.setParameters(params);
            device.startPreview();
            device.autoFocus(AutoFocusCallback);
            Assert("Set focus point");
        } else {
            device.autoFocus(AutoFocusCallback);
        }
    }

    boolean SetFocusMode (int camera, int mode) {
        if (!inspectedDevice) PerformInspection();
        if (activeCamera != camera) {
            Log("NatCam Error: Can only set focus mode on active camera");
            return false;
        }
        boolean ret = false;
        Camera device = mCamera;
        Camera.Parameters params = mCamera.getParameters(); //Parameters[camera];
        FocusModes[camera] = FocusMode (mode % 2);
        device.cancelAutoFocus();
        if (params.getSupportedFocusModes().contains(FocusModes[camera])) {
            params.setFocusMode(FocusModes[camera]);
            Assert("Set focus mode to " + mode);
            ret = true;
        }
        if (params.getMaxNumFocusAreas() > 0) params.setFocusAreas(null);
        params.setPreviewFpsRange(Framerates[camera][0], Framerates[camera][1]);
        device.setParameters(params);
        device.startPreview();
        return ret;
    }

    boolean SetFlash (int camera, int mode) {
        if (!inspectedDevice) PerformInspection();
        boolean ret = false;
        Camera.Parameters params = IntrinsicProperties[camera];
        if (params.getSupportedFlashModes() != null) { //Some devices don't support any flash whatsoever
            String flashMode = FlashMode (mode);
            if (params.getSupportedFlashModes().contains(flashMode)) {
                FlashModes[camera] = flashMode;
                Assert("Set flash mode to " + mode);
                ret = true;
            }
            else Log("NatCam Error: Camera does not support "+flashMode);
        }
        return ret;
    }

    boolean SetTorch (int camera, int state) {
        if (!inspectedDevice) PerformInspection();
        if (activeCamera != camera) {
            Log("NatCam Error: Can only set torch on active camera");
            return false;
        }
        boolean ret = false;
        Camera device = mCamera;
        Camera.Parameters params = mCamera.getParameters(); //Parameters[camera];
        String flashMode = state == 1 ? params.FLASH_MODE_TORCH : params.FLASH_MODE_OFF;
        List<String> flashModes = params.getSupportedFlashModes();
        if (flashModes == null) {
            Log("NatCam Error: Camera does not support torch");
            return false;
        }
        if (flashModes.contains(flashMode)) {
            params.setFlashMode(flashMode);
            Assert(state == 1 ? "Enabled torch" : "Disabled torch");
            ret = true;
        }
        else Log("NatCam Error: Camera does not support torch");
        params.setPreviewFpsRange(Framerates[camera][0], Framerates[camera][1]); //On some devices, if this isn't done, setParameters will fail
        device.setParameters(params);
        device.startPreview();
        return ret;
    }

    boolean SetZoom (int camera, float ratio) {
        if (!inspectedDevice) PerformInspection();
        if (activeCamera != camera) {
            Log("NatCam Error: Can only set focus on active camera");
            return false;
        }
        boolean ret = false;
        Camera device = mCamera;
        Camera.Parameters params = mCamera.getParameters(); //Parameters[camera];
        if (params.isSmoothZoomSupported()) {
            int zoom = Math.round(params.getMaxZoom() * ratio);
            device.startSmoothZoom(zoom);
            ret = true;
        }
        return ret;
    }

    void SetPhotoSaveMode (int saveMode) {
        photoSaveMode = saveMode;
    }
    //endregion


    //region ---Operations---

    void PlayPreview (int camera) {
        if (!initializedSession) InitializeSession(camera);
        activeCamera = camera;
        mCameraHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mCamera != null) {
                    mCamera.release();
                    mCamera = null;
                }
                mCamera = GetCamera(activeCamera, previewSurfaceTex);
                Camera.Parameters params = mCamera.getParameters();
                params.setPreviewSize(Resolutions[activeCamera].width, Resolutions[activeCamera].height);
                params.setPreviewFpsRange(Framerates[activeCamera][0], Framerates[activeCamera][1]);
                Camera.Size photoSize = HighestPhotoResolution(params);
                params.setPictureSize(photoSize.width, photoSize.height);
                mCamera.setParameters(params);
                //Set preview callback
                mCamera.setPreviewCallbackWithBuffer(PreviewCallback);
                //Restart preview
                mCamera.startPreview();
                mCamera.addCallbackBuffer(PreviewBuffer);
                Assert("Started session");
            }
        });
    }

    void PausePreview () {
        mCamera.stopPreview();
    }

    void TerminateOperations () {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }
        else return;
        //Nullify all instance variables
        _width = 0;
        _height = 0;
        initializedSession = false;
        inspectedDevice = false;
        activeCamera = -1;
        photoSaveMode = 0;
        IntrinsicProperties = null;
        Resolutions = null;
        Framerates = null;
        FocusModes = null;
        FlashModes = null;
        mrDetection = false;
        isScanningCodes = false;
        PreviewBuffer = null;
        yBuffer = null;
        uvBuffer = null;
        if (detector != null) detector.release();
        detector = null;
        previewSurfaceTex.release();
        previewSurfaceTex = null;
        mCameraHandler.removeCallbacksAndMessages(null);
        mrProcessor.removeCallbacksAndMessages(null);
        /*
        //BUG //Mono seems to have a problem with calling Thread.quit()
        mCameraThread.quit();
        mrProcessingThread.quit();
        mCameraHandler = null;
        mrProcessor = null;
        mCameraThread = null;
        mrProcessingThread = null;
        */
        RequestRenderCallback(3); //Teardown the rendering pipeline
        instance = null; //Nullify static instance
    }

    void SwitchCamera (int camera) {
        ReportUpdateState(false);
        mCamera.stopPreview();
        mCamera.release();
        mCamera = null;
        if (Resolutions[camera].width != _width || Resolutions[camera].height != _height) {
            _width = Resolutions[camera].width;
            _height = Resolutions[camera].height;
            PreviewBuffer = null;
            PreviewBuffer = new byte[4096 + _width * _height * 12 / 8];
            yBuffer = null;
            uvBuffer = null;
            yBuffer = ByteBuffer.allocateDirect(_width * _height);
            uvBuffer = ByteBuffer.allocateDirect(_width * _height / 2);
            yBuffer.order(ByteOrder.nativeOrder());
            uvBuffer.order(ByteOrder.nativeOrder());
        }
        //Play
        PlayPreview(camera);
    }

    void CaptureStill () {
        mCameraHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (FlashModes[activeCamera] != null) {
                        Camera.Parameters params = mCamera.getParameters();
                        params.setFlashMode(FlashModes[activeCamera]);
                        params.setPreviewFpsRange(Framerates[activeCamera][0], Framerates[activeCamera][1]);
                        mCamera.setParameters(params);
                    }
                    mCamera.takePicture(null, null, PhotoCallback);
                } catch (Exception e) {
                    Log("NatCam: Failed to capture photo with exception: " + e);
                }
            }
        });
    }
    //endregion


    //region ---Callbacks---

    Camera.PreviewCallback PreviewCallback = new Camera.PreviewCallback() {
        @Override
        public void onPreviewFrame(byte[] data, Camera camera) {
            mCamera.addCallbackBuffer(PreviewBuffer);
            ReportUpdateState(true);
            CheckForBarcodes();
            UpdateDimensions(_width, _height);
            if (!InitializedRenderer()) return; //Automatically request for renderer initialization native side
            UpdateComponentBuffers();
            RequestRenderCallback(2);
            Assert("Preview Callback");
        }
    };

    Camera.PictureCallback PhotoCallback = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            if (data != null) {
                Log("NatCam: Captured photo");
                ReportPhoto(data, data.length);
                SavePhotoToDisk(mrProcessor, photoSaveMode, data, _rotation, _flip);
            }
            mCamera.startPreview();
        }
    };

    Camera.AutoFocusCallback AutoFocusCallback = new Camera.AutoFocusCallback() {
        @Override
        public void onAutoFocus(boolean success, Camera camera) {
            Assert(success ? "Focus was successful" : "Focus was unsuccessful");
            camera.cancelAutoFocus();
            int index = activeCamera;
            Camera.Parameters params = camera.getParameters(); //Parameters[index];
            String focusResetMode = FocusModes[index];
            if (params.getSupportedFocusModes().contains(focusResetMode)) params.setFocusMode(focusResetMode);
            if (params.getMaxNumFocusAreas() > 0) params.setFocusAreas(null);
            params.setPreviewFpsRange(Framerates[index][0], Framerates[index][1]);
            camera.setParameters(params);
            camera.startPreview();
        }
    };
    //endregion


    //region ---Utility---

    static ByteBuffer GetYBuffer () { return instance.yBuffer; }

    static ByteBuffer GetUVBuffer () { return instance.uvBuffer; }

    void SetSessionCamera (int camera) {
        activeCamera = camera;
        if (mCamera != null) {
            mCamera.release();
            mCamera = null;
        }
        mCamera = GetCamera(camera, previewSurfaceTex);
    }

    void SetRotation (float rotation, float flip) { //Used for orienting the captured photo
        _rotation = rotation;
        _flip = flip;
    }

    void UpdateComponentBuffers() {
        yBuffer.put(PreviewBuffer, 0, _width * _height);
        yBuffer.position(0);
        uvBuffer.put(PreviewBuffer, _width * _height, _width * _height / 2);
        uvBuffer.position(0);
    }

    void CheckForBarcodes () {
        if (mrDetection && !isScanningCodes && mrProcessor != null) {
            mrProcessor.post(new Runnable() {
                @Override
                public void run() {
                    isScanningCodes = true;
                    ScanForBarcodes();
                }
            });
        }
    }

    void ScanForBarcodes () {
        //Setup detector if null
        if (detector == null) {
            Assert("Creating Barcode Detector");
            detector = new BarcodeDetector.Builder(UnityPlayer.currentActivity.getApplicationContext())
                    .setBarcodeFormats(
                            Barcode.QR_CODE
                                    | Barcode.EAN_13
                                    | Barcode.EAN_8
                                    | Barcode.DATA_MATRIX
                                    | Barcode.PDF417
                                    | Barcode.CODE_128
                                    | Barcode.CODE_93
                                    | Barcode.CODE_39
                                    | Barcode.ISBN)
                    .build();
            Log("NatCam: Initialized Barcode Detector");
        }
        if (!detector.isOperational()) {
            Log("NatCam Error: Failed to initialize barcode detector");
            return;
        }
        if (detectorFrame == null) {
            detectorFrame = new Frame.Builder()
                    .setImageData(ByteBuffer.wrap(PreviewBuffer), _width, _height, ImageFormat.NV21)
                    .setRotation(Frame.ROTATION_90) //CHECK //Rotate the frame
                    .build();
            Assert("Created detector frame at "+_width+"x"+_height);
        }
        else if (detectorFrame.getMetadata().getWidth() != _width || detectorFrame.getMetadata().getHeight() != _height) { //On resize
            detectorFrame = new Frame.Builder()
                    .setImageData(ByteBuffer.wrap(PreviewBuffer), _width, _height, ImageFormat.NV21)
                    .setRotation(Frame.ROTATION_90) //CHECK //Rotate the frame
                    .build();
            Assert("Resizing detector frame to "+_width+"x"+_height);
        }
        Assert("Analyzing frame for barcodes");
        SparseArray<Barcode> barcodes = detector.detect(detectorFrame);
        if (barcodes.size() > 0) {
            Assert("Found "+barcodes.size()+" barcodes");
            String code = "";
            for (int i = 0; i < barcodes.size(); i++) {
                code += MRCodeFormat(barcodes.valueAt(i).format) + "::" + barcodes.valueAt(i).rawValue + (i == (barcodes.size() - 1) ? "" : ";");
            }
            ReportBarcode(code);
        }
        isScanningCodes = false;
    }

    void SuspendProcess () {
        if (mCamera == null) return;
        mCamera.stopPreview();
        mCamera.release();
        mCamera = null;
    }

    void ResumeProcess (boolean wasPlaying) {
        if (wasPlaying) PlayPreview(activeCamera);
        else if (activeCamera > -1) mCamera = GetCamera(activeCamera, previewSurfaceTex); //Make sure a camera was active
    }
    //endregion


    //region ---Singleton Pattern---

    public NatCamNativeActivity () {
        //Singleton pattern
        instance = this;
    }
    private static NatCamNativeActivity instance = null;
    public static NatCamNativeActivity instance () {
        if(instance == null) {
            instance = new NatCamNativeActivity();
        }
        return instance;
    }
    //endregion
}
